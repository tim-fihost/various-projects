import art
import os
print(art.logo)
print("Welcome to the secret auction program.")
data = {}
def add_data(name,bid):
    data[name] = bid
def winner(input_data):
    data_max = 0
    for name,i in input_data.items():
        if i > data_max:
            data_max = i
    print(f"Winner is {name} with a bit of ${data_max}")
while True:
    name = input("What is your name? ")
    bid = int(input("What is your bid? $"))
    add_data(name,bid)
    print(data)
    a = input("Are there any other bidders? Type 'yes' or 'no':\n").lower()
    if a== "yes":
        os.system('cls')
    else:
        winner(data)
        break