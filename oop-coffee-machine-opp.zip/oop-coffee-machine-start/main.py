import os
from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine
order_menu = Menu()
coffe = CoffeeMaker()
bank = MoneyMachine()
print("Hello mate!\nWhat would you like to order?")
while True:
    print(order_menu.get_items())
    user_order = str(input("Select one or l to leave: "))
    if user_order == "l":
        print("Have a nice day")
        break
    elif user_order == "info":
        '''There is a secret key for admins which is info 
        and will provide information about resources in coffe machine'''
        coffe.report()
        print("========================")
        bank.report()

    else:
        try:
            order = order_menu.find_drink(user_order)
            if not coffe.is_resource_sufficient(order):
                print("Feel the means, First!")
            else:
                #Payment
                price = order.cost
                print(f"Price {price}$")
                if bank.make_payment(price):
                    print("=======================")
                    here_is_coffe = coffe.make_coffee(order)
                    print("Do you want to make a new order Y/N?")
                    answer = str(input()).upper()
                    if answer == 'Y':
                        os.system("clear") #Note if you use Windows instead 'clear' will be 'cls'
                    else:
                        break 
        except AttributeError:
            print("Miss typed, try again")