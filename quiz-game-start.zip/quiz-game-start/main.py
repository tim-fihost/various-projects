from question_model import Question
from data import question_data
from quiz_brain import Quizbrain
q_class_list = []

for question in question_data:
    question_text = question['question']
    question_answer = question['correct_answer']
    content = Question(question_text,question_answer)
    q_class_list.append(content)

quiz = Quizbrain(q_class_list)
loop_condition = True
while loop_condition:
    quiz.next_qestion()
    loop_condition = quiz.still_has_questions()
print("You've completed the quiz")
print(f"Your final score was: {quiz.score}/{quiz.question_number}")


