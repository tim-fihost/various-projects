import pandas
data = pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")
#Gray
gray = (data.value_counts("Primary Fur Color"))["Gray"] 
print(f"Gray: {gray}")
#Cinnamon
cinnamon = (data.value_counts("Primary Fur Color"))["Cinnamon"]
print(f"Red: {cinnamon}")
#black
black = (data.value_counts("Primary Fur Color"))["Black"] 
print(f"Black: {black}")

data_for_csv = {
    "Fur Color" : ["Gray","Cinnamon","Black"],
    "Count" : [gray,cinnamon,black]
}
df = pandas.DataFrame(data_for_csv)
df.to_csv("new_data.csv")