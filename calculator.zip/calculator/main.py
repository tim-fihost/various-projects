import art
def add(n1,n2):
    return n1+n2
def subtract(n1,n2):
    return n1-n2
def multiply(n1,n2):
    return n1*n2
def divide(n1,n2):
    return n1/n2
def calculator():
    print(art.logo)
    num1 = float(input("What is the first number?: "))
    operations = {
    '+':add,
    '-':subtract,
    '*':multiply,
    '/':divide}
    for i in operations.keys():
        print(i)
    or_not = True
    while or_not:
        symbol = input("Pick an operation: ")
        num2 = float(input("What is the next number?: "))
        calc_function = operations[symbol]
        answer = calc_function(num1,num2)
        print(f"{num1} {symbol} {num2} = {answer}")
        condition = input(f"Type 'y' to continue calculating with {answer},'b' to leave ,or type 'n' to start a new calculation: ")
        if condition == 'y':
            num1 = answer
        elif condition == 'b':
            break
        else:
            or_not = False
            calculator()
calculator()         