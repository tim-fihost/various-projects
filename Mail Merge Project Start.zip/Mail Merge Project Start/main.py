#Creates a letter using starting_letter.txt
with open("Mail+Merge+Project+Start\\Mail Merge Project Start\\Input\\Letters\\starting_letter.txt","r") as file1:
    content = file1.read()

#for each name in invited_names.txt
with open("Mail+Merge+Project+Start\\Mail Merge Project Start\\Input\\Names\\invited_names.txt","r") as file2:
    names = file2.read()

#Replace the [name] placeholder with the actual name.
names = names.split("\n")
for name in names:
    txt = content.replace("[name]",name)
    #Save the letters in the folder "ReadyToSend".
    with open(f"Mail+Merge+Project+Start\\Mail Merge Project Start\\Output\\{name}.txt","w") as outputfile:
        outputfile.write(txt)

print("DONE!")

    