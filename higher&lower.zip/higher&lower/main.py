import random
import art
import game_data
import os
def unpacK_and_compare(name1,name2):
    """This function unpacks dictionary
    Produces two variables.
    And copmares!"""
    a = name1['follower_count']
    b = name2['follower_count']
    if a > b:
        return name1
    else:
        return name2
def randomize(data):
    """This function takes banch of data,
    Then randomizes it.
    Finaly returns single dictionary"""
    return random.choice(data)
A = randomize(game_data.data)
score = 0
while True:
    print(art.logo)
    B = randomize(game_data.data)
    if B == A:
        B = randomize(game_data.data)
    winner = unpacK_and_compare(A,B)
    print(f"Compare A {A['name']}, a {A['description']}, from {A['country']};")
    print(art.vs)
    print(f"Against B: {B['name']}, a {B['description']}, from {B['country']};")
    user_answer = input("Who has more followers? Type 'A' or 'B': ").upper()
    if user_answer == 'A':
        if A == winner:
            print("Right")
            A = winner
            score +=1
        else:
            print(f"sorry that's wrong final score is final score: {score}")
            break
    elif user_answer == 'B':
        if B == winner:
            A = B
            print("Right")
            score +=1
        else:
            print(f"sorry that's wrong final score is final score: {score}")
            break
    os.system('cls')