import art
import random
import os
cards = [11,2,3,4,5,6,7,8,9,10,10,10,10]
def shuffle():
    a = random.choice(cards)
    b = random.choice(cards)
    cards_list = [a,b]
    return cards_list
def computer():
    computer_cards = shuffle()
    sum = 0 
    for i in computer_cards:
        sum+=i    
    while sum < 17:
        this_card = random.choice(cards)
        computer_cards.append(this_card)
        sum += this_card
    print("=====Computer=====")
    print("Computer's first card:",computer_cards[0])
    return sum,computer_cards
def user():
    user_cards = shuffle()
    sum = 0
    while True:
        print("Your cards:",user_cards)
        user_will = input("Type 'y to get another card, type 'n' to pass: ")
        if user_will == 'y':
            user_cards.append(random.choice(cards))
        elif user_will == 'n':
            break
        else: 
            print("Wrong command!")
    for i in user_cards:
        sum +=i
    print(f"Your final hand: {user_cards}, current score {sum}")
    return sum, user_cards
def board():
    print("\n\n")
    computer_sum,computer_output_list=computer()
    user_sum,user_output_list = user()
    if user_sum > computer_sum and not user_sum >21:
        print(f"\tYour final hand: {user_output_list}, final score {user_sum} ") 
        print(f"\tComputer final hand: {computer_output_list}, final score {computer_sum}")
        print("\tYou won!")
    elif user_sum>21:
        print(f"\tYour final hand: {user_output_list}, final score {user_sum} ")
        print("\tYou went over, you lost")
        print("\tComputer won!")
    elif user_sum < computer_sum and not computer_sum > 21:
        print(f"\tYour final hand: {user_output_list}, final score {user_sum} ")
        print(f"\tComputer final hand: {computer_output_list}, final score {computer_sum} ")
        print("\tComputer won!")
    elif computer_sum >21:
        print(f"\tYour final hand: {user_output_list}, final score {user_sum} ")
        print(f"\tComputer final hand: {computer_output_list}, final score {computer_sum} ")
        print("\tComputer went over! You won")
    elif computer_sum == user_sum:
        print(f"\tYour final hand: {user_output_list}, final score {user_sum} ")
        print(f"\tComputer final hand: {computer_output_list}, final score {computer_sum} ")
        print("DRAW")
        
while True:
    game = input("Do you want to play a game of Blackjack? Type 'y' or 'n': ")
    if game == "y":
        os.system('cls')
        print(art.logo)
        board()
        print("\n")
    else:
        print("GoodBye!!!!!\nHave a nice day")
        break